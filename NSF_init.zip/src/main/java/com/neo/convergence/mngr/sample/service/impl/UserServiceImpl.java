package com.neo.convergence.mngr.sample.service.impl;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.neo.convergence.mngr.sample.dao.UserDAO;
import com.neo.convergence.mngr.sample.model.AlreadyExistingEmailException;
import com.neo.convergence.mngr.sample.model.AlreadyExistingIdException;
import com.neo.convergence.mngr.sample.model.RegisterRequest;
import com.neo.convergence.mngr.sample.model.UserVO;
import com.neo.convergence.mngr.sample.service.UserService;

@Service("userService")
public class UserServiceImpl implements UserService {

	@Resource(name="userDAO")
    private UserDAO userDAO;

    @Override
    public void register(RegisterRequest regReq) throws Exception {
        UserVO email = userDAO.selectByEmail(regReq.getEmail());
        if(email!=null) {
            throw new AlreadyExistingEmailException(regReq.getEmail()+" is duplicate email.");
        }
        UserVO id = userDAO.selectById(regReq.getId());
        if(id!=null) {
            throw new AlreadyExistingIdException(regReq.getId()+" is duplicate id.");
        }
        userDAO.insertUser(regReq);
    }

}

