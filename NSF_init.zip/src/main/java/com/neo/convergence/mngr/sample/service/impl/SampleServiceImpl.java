package com.neo.convergence.mngr.sample.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.neo.convergence.mngr.sample.dao.SampleDAO;
import com.neo.convergence.mngr.sample.model.SampleVO;
import com.neo.convergence.mngr.sample.service.SampleService;

/**
 * 시스템명 : 신입사원-프로젝트2<br>
 * com.neo.convergence.mngr.sample.service.impl.SampleServiceImpl<br>
 * 클래스 설명 : 샘플 Interface 구현 Class
 *
 * @author sampler
 * @since 2019. 05. 03
 * @version 1.0.0
 * @see
 *
 * <pre>
 * << 개정이력(Modification Infomation) >>
 *
 *      수정일       수정자              수정내용
 *  ------------   ----------   -------------------------------
 *  2019. 05. 03    sampler     최초생성
 * </pre>
 */
@Service("sampleService")
public class SampleServiceImpl implements SampleService {

    @SuppressWarnings("unused")
    private static final Logger LOGGER = LoggerFactory.getLogger(SampleServiceImpl.class);

    /** sampleDAO */
    @Resource(name="sampleDAO")
    private SampleDAO sampleDAO;

    @Override
    public int selectCntSample(SampleVO sampleVO) {
        return sampleDAO.selectCntSample(sampleVO);
    }

    @Override
    public List<SampleVO> selectSampleList(SampleVO sampleVO) {
        return sampleDAO.selectSampleList(sampleVO);
    }

    @Override
    public SampleVO selectSample(SampleVO sampleVO) {
        return sampleDAO.selectSample(sampleVO);
    }

    @Override
    public int insertSample(SampleVO sampleVO) {
        return sampleDAO.insertSample(sampleVO);
    }

    @Override
    public int updateSample(SampleVO sampleVO) {
        return sampleDAO.updateSample(sampleVO);
    }
}