package com.neo.convergence.mngr.sample.web;

import javax.annotation.Resource;

import org.springframework.stereotype.Controller;
import org.springframework.validation.Errors;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.neo.convergence.mngr.sample.model.AlreadyExistingEmailException;
import com.neo.convergence.mngr.sample.model.AlreadyExistingIdException;
import com.neo.convergence.mngr.sample.model.RegisterRequest;
import com.neo.convergence.mngr.sample.model.RegisterRequestValidator;
import com.neo.convergence.mngr.sample.service.UserService;

@Controller
public class UserController {
	@RequestMapping("/index.do")
	public String index() throws Exception {
		return "index";
	}
	@RequestMapping("/register/step1.do")
	public String step1() throws Exception {
		return "step1";
	}

	@RequestMapping("/register/step2.do")
    public ModelAndView step2(@RequestParam(value="agree", defaultValue="false") Boolean agree) throws Exception {
        if(!agree) {
            ModelAndView mv = new ModelAndView("step1");
            return mv;
        }
        ModelAndView mv = new ModelAndView("step2");
        mv.addObject("registerRequest", new RegisterRequest());
        return mv;
    }
	@Resource(name="userService")
    private UserService userSer;

    @RequestMapping("/register/step3.do")
    public ModelAndView step3(RegisterRequest regReq, Errors errors) throws Exception{
        new RegisterRequestValidator().validate(regReq, errors);
        if(errors.hasErrors()) {
            ModelAndView mv = new ModelAndView("step2");
            return mv;
        }
        try {
            userSer.register(regReq);
        } catch (AlreadyExistingEmailException e) {
            errors.rejectValue("email", "duplicate", "�̹� ���Ե� �̸����Դϴ�.");
            ModelAndView mv = new ModelAndView("step2");
            return mv;
        } catch (AlreadyExistingIdException e) {
            errors.rejectValue("id", "duplicate", "�̹� ���Ե� ���̵��Դϴ�.");
            ModelAndView mv = new ModelAndView("step2");
            return mv;
        }
        ModelAndView mv = new ModelAndView("step3");
        return mv;
    }

}