package com.neo.convergence.mngr.sample.model;

@SuppressWarnings("serial")
public class AlreadyExistingIdException extends RuntimeException{
    public AlreadyExistingIdException(String string) {
		// TODO Auto-generated constructor stub
	}

	public void AlreadyExistingEmailException(String message) {
        //super(message);
    }
}
