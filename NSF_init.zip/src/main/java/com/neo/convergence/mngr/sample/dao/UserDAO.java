package com.neo.convergence.mngr.sample.dao;

import org.springframework.stereotype.Repository;

import com.neo.convergence.mngr.sample.model.RegisterRequest;
import com.neo.convergence.mngr.sample.model.UserVO;

import egovframework.rte.psl.dataaccess.EgovAbstractMapper;

@Repository("userDAO")
public class UserDAO extends EgovAbstractMapper {
	 public UserVO selectByEmail(String email) {
	        return (UserVO)selectOne("user.selectByEmail", email);
	    }

	    public UserVO selectById(String id) {
	        return (UserVO)selectOne("user.selectById", id);
	    }

	    public void insertUser(RegisterRequest regReq) {
	        insert("user.register", regReq);
	    }


}

