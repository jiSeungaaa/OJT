package com.neo.convergence.mngr.sample.web;

//import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.neo.convergence.mngr.sample.model.SampleVO;
import com.neo.convergence.mngr.sample.service.SampleService;

//import egovframework.rte.ptl.mvc.tags.ui.pagination.PaginationInfo;

/**
 * 시스템명 : 신입사원-프로젝트2<br>
 * com.neo.convergence.mngr.sample.web.SampleController<br>
 * 클래스 설명 : 샘플 Controller
 *
 * @author sampler
 * @since 2019. 05. 03
 * @version 1.0.0
 * @see
 *
 * <pre>
 * << 개정이력(Modification Infomation) >>
 *
 *      수정일       수정자              수정내용
 *  ------------   ----------   -------------------------------
 *  2019. 05. 03    sampler     최초생성
 * </pre>
 */
@Controller
@RequestMapping(value="/mngr/sample")
public class SampleController {

    @SuppressWarnings("unused")
    private static final Logger LOGGER = LoggerFactory.getLogger(SampleController.class);

    /** sampleService */
    @Resource(name = "sampleService")
    SampleService sampleService;

    /**
     * 샘플 목록 조회
     * @param request
     * @param response
     * @param searchVO
     * @param model
     * @return
     * @throws Exception
     */
    @RequestMapping("/sampleList.do")
    public String sampleList(HttpServletRequest request, HttpServletResponse response
        , @ModelAttribute("searchVO") SampleVO searchVO, Model model) throws Exception {

//        int totCnt = 0;
//
//        // set paginationInfo
//        PaginationInfo paginationInfo = new PaginationInfo();
//        paginationInfo.setCurrentPageNo(searchVO.getPageIndex());
//        paginationInfo.setRecordCountPerPage(searchVO.getPageUnit());
//        paginationInfo.setPageSize(searchVO.getPageSize());

//        // get count of list, set paginationInfo
//        totCnt = sampleService.selectCntSample(searchVO);
//        paginationInfo.setTotalRecordCount(totCnt);

//        // 마지막 페이지 보정 (삭제, 검색 등)
//        if(paginationInfo.getCurrentPageNo() != 1
//                && paginationInfo.getCurrentPageNo() > paginationInfo.getTotalPageCount()) {
//            paginationInfo.setCurrentPageNo(paginationInfo.getTotalPageCount());
//        }

//        // set paging condition
//        searchVO.setFirstIndex(paginationInfo.getFirstRecordIndex());
//        searchVO.setLastIndex(paginationInfo.getLastRecordIndex());
//        searchVO.setRecordCountPerPage(paginationInfo.getRecordCountPerPage());
//        model.addAttribute("paginationInfo", paginationInfo);
//
//        // get list
//        List<SampleVO> sampleList = sampleService.selectSampleList(searchVO);
//        model.addAttribute("sampleList", sampleList);

        return "/mngr/sample/sampleList";
    }

//    @RequestMapping("/sampleView.do")
//    @RequestMapping("/sampleReg.do")
//    @RequestMapping("/sampleRegAction.do")
//    @RequestMapping("/sampleMod.do")
//    @RequestMapping("/sampleModAction.do")
//    @RequestMapping("/sampleDelAction.do")
}