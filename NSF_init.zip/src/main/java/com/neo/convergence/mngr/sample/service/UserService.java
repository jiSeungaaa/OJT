package com.neo.convergence.mngr.sample.service;

import com.neo.convergence.mngr.sample.model.RegisterRequest;

public interface UserService {
	 void register(RegisterRequest regReq) throws Exception;


}
