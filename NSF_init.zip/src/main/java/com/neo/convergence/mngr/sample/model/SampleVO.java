package com.neo.convergence.mngr.sample.model;

/**
 * 시스템명 : 신입사원-프로젝트2<br>
 * com.neo.convergence.mngr.sample.model.SampleVO<br>
 * 클래스 설명 : 샘플 VO
 *
 * @author sampler
 * @since 2019. 05. 03
 * @version 1.0.0
 * @see
 *
 * <pre>
 * << 개정이력(Modification Infomation) >>
 *
 *      수정일       수정자              수정내용
 *  ------------   ----------   -------------------------------
 *  2019. 05. 03    sampler     최초생성
 * </pre>
 */
public class SampleVO {

    // 검색
    /** 검색-검색조건 */
    private String searchCondition;
    /** 검색-검색어 */
    private String searchKeyword;

    // 공통
    /** 행 번호 */
    private String rnum;
    /** 번호 */
    private String no;

    public String getSearchCondition() {
        return searchCondition;
    }
    public void setSearchCondition(String searchCondition) {
        this.searchCondition = searchCondition;
    }
    public String getSearchKeyword() {
        return searchKeyword;
    }
    public void setSearchKeyword(String searchKeyword) {
        this.searchKeyword = searchKeyword;
    }
    public String getRnum() {
        return rnum;
    }
    public void setRnum(String rnum) {
        this.rnum = rnum;
    }
    public String getNo() {
        return no;
    }
    public void setNo(String no) {
        this.no = no;
    }
}