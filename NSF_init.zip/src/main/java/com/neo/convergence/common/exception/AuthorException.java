package com.neo.convergence.common.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

/**
 * 시스템명 : 신입사원-프로젝트2<br>
 * com.neo.convergence.common.exception.AuthorException<br>
 * 클래스 설명 :
 *
 * @author sampler
 * @since 2019. 05. 03
 * @version 1.0.0
 * @see
 *
 * <pre>
 * << 개정이력(Modification Infomation) >>
 *
 *      수정일       수정자              수정내용
 *  ------------   ----------   -------------------------------
 *  2019. 05. 03    sampler     최초생성
 * </pre>
 */
@ResponseStatus(value=HttpStatus.UNAUTHORIZED, reason="권한이 없습니다.")
public class AuthorException extends RuntimeException {

    private static final long serialVersionUID = 1L;

    private String message;

    public AuthorException(String message) {
        super();
        this.message = message;
    }

    public AuthorException(String message, Exception ex) {
        super();
        this.message = message;
    }

    @Override
    public String getMessage() {
        String result = "";
        if("CC".equals(message)) {
            result = "등록";
        } else if("CU".equals(message)) {
            result = "수정";
        } else if("CD".equals(message)) {
            result = "삭제";
        } else if("CR".equals(message)) {
            result = "읽기";
        } else if("FD".equals(message)) {
            result = "파일다운로드";
        } else if("FU".equals(message)) {
            result = "파일업로드";
        } else if("ED".equals(message)) {
            result = "엑셀다운로드";
        } else if("EU".equals(message)) {
            result = "엑셀업로드";
        } else {
            result = "";
        }
        return result + "권한이 없습니다.";
    }
}
