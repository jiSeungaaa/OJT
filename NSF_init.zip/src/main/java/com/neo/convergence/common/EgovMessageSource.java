package com.neo.convergence.common;

import java.util.Locale;

import org.springframework.context.support.ReloadableResourceBundleMessageSource;

public class EgovMessageSource extends ReloadableResourceBundleMessageSource {

    private ReloadableResourceBundleMessageSource reloadableResourceBundleMessageSource;

    /**
     * getReloadableResourceBundleMessageSource()
     * @param reloadableResourceBundleMessageSource - resource MessageSource
     * @return ReloadableResourceBundleMessageSource
     */
    public void setReloadableResourceBundleMessageSource(ReloadableResourceBundleMessageSource reloadableResourceBundleMessageSource) {
        this.reloadableResourceBundleMessageSource = reloadableResourceBundleMessageSource;
    }

    /**
     * getReloadableResourceBundleMessageSource()
     * @return ReloadableResourceBundleMessageSource
     */
    public ReloadableResourceBundleMessageSource getReloadableResourceBundleMessageSource() {
        return reloadableResourceBundleMessageSource;
    }

    /**
     * 정의된 메세지 조회
     * @param code - 메세지 코드
     * @return String
     */
    public String getMessage(String code) {
        return getReloadableResourceBundleMessageSource().getMessage(code, null, Locale.getDefault());
    }

    /**
     * 기본 Locale 메세지 파일에 등록된 메세지를 얻는다.
     *
     * @param code 메세지 코드
     * @param arg 메세지 파라메터 값
     * @return 메세지내용
    */
    public String getMessage(String code, Object[] arg) {
        return getReloadableResourceBundleMessageSource().getMessage(code, arg, Locale.getDefault()); //getDefault());
    }
}